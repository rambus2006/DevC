#include<stdio.h>
main(){
	int a,b;
	scanf("%d%d",&a,&b);
	printf("%d\n%d\n%d\n%d\n%d\n%.2lf\n",a+b,a-b,a*b,a%b,(float)a/(float)b);
	}

