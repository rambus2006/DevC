#include<stdio.h>
main(){
	int a;
	scanf("%d",&a);
	printf("%X",a);
	}

