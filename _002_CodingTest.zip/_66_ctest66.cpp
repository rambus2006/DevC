#include<stdio.h>
main(){
	int a,b,c;
	scanf("%d%d%d",&a,&b,&c);
	printf("%d",a);
	if(a%2==0) printf("even\n");
	else printf("odd\n");
	printf("%d",b);
	if(b%2==0) printf("even\n");
	else printf("odd\n");
	printf("%d",c);
	if(c%2==0) printf("even\n");
	else printf("odd\n");
	
}

