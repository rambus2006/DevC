#include<stdio.h>
main(){
	int n,num;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&num);
		printf("%d\n",num);
	}	
}	

