#include<stdio.h>
main(){
	int i=1,n;
	scanf("%c",&n);
	while(i<=n)
	{
		printf("%d\n",i);
		i++;
	}
		
	
}	

