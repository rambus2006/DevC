#include<stdio.h>
main(){
	for(int i=1;i<=100;i++)
	{
		sum+=i;
		
	}
	printf("%d",sum);
	
}	

