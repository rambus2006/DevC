#include<stdio.h>
main(){
	char x;
	scanf("%c",&x);
	for(char t='a';t<=x;t++)
	{
		printf("%c",t);
	}
		
	
}	

