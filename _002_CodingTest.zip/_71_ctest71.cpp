#include<stdio.h>
main(){
	int a;
	RE:
		scanf("%d",&a);
		if(a!=0){
			printf("%d\n",&a);
			goto RE:
		}
		
		
		
		
	}
	
}

