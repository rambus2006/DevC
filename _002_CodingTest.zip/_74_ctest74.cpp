#include<stdio.h>
main(){
	int i,n;
	scanf("%d",&n);
	for(i=1;i>=1;i--){
		printf("%d\n",i);
	}
}	

