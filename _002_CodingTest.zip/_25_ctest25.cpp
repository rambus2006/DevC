#include<stdio.h>
main(){
	int a,b,c,d,e;
	scanf("%1d%1d%1d%1d%1d",&a,&b,&c,&d,&e);
	}
}
