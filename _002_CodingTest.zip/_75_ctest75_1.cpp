#include<stdio.h>
main(){
	char t='a',x;
	scanf("%c",&x);
	do{
		
		printf("%c",t);
		t++;
	}
	while(t<=x);
		
	
}	

