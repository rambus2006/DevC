#include<stdio.h>
main(){
	long long int a;
	scanf("%lld",&a);
	printf("%lld",a);
	}

