#include<stdio.h>
//활동지에는 20번
int main(void){
	char a;
	char data[51];
	scanf("%s",data); //배열을 입력할 때 & 기호를 넣지 않는다. 
	printf("%s",data);
}
