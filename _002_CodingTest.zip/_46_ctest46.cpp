#include<stdio.h>
main(){
	int a,b,c;
	scanf("%d%d%d",&a,&b,&c);
	printf("%d\n%.1lf",a+b+c,(float)(a+b+c)/(float)3);
}

