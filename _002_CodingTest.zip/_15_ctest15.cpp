#include<stdio.h>
//문제지에는 17번이다. 
int main(void){
	int a;
	printf("정수를를 입력하세요 : ");
	scanf("%d",&a);
	printf("%d %d %d",a,a,a);
	
}
