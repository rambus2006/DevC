#include<stdio.h>
//활동지에는 20번
int main(void){
	int a,b;
	scanf("%d-%d",&a,&b);
	printf("%06d%07d",a,b);
}
