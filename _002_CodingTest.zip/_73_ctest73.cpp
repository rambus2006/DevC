#include<stdio.h>
main(){
	int a;
	scanf("%d",&a);
	while(a!=0){
		printf("%d\n",a);
		scanf("%d",&a);
	}
}	

