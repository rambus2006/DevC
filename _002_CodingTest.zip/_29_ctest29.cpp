#include<stdio.h>
main(){
	double a;
	scanf("%lf",&a);
	printf("%lf",a);
	}

