#include<stdio.h>
//문제지에는 15번이다. 
int main(void){
	float a;
	printf("아스키코드를 입력하세요 : ");
	scanf("%.2f",&a);
	printf("%.2f",a);
	
}
