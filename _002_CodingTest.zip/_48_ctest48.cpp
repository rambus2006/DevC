#include<stdio.h>
main(){
	int a,b;
	scanf("%d%d",&a);
	printf("%d",a<<b);
}

