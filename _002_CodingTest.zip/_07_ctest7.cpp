#include<stdio.h>

int main(void){
	printf("\"C:\\Download\\hello.cpp\"");

}
