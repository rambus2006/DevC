#include<stdio.h>
main(){
	char t='a',x;
	scanf("%c",&x);
	while(t<=x){
		printf("%c",t);
		t++;
	}
}	

