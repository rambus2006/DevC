#include<stdio.h>
main(){
		char a ;
		scanf("%c",&a);  
		printf("%c",a+1);
	}

