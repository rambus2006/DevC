#include<stdio.h>
main(){
	int a;
	scanf("%d",&a);
	if(a>0){
		printf("plus\n");
		if(a%2==0){
			printf("even\n");
		}else{
			printf("odd\n");
		}
	}
	else{
		printf("minus\n");
		if(a%2==0){
			printf("even\n");
		}else{
			printf("odd\n");
		}
	}

	
}

