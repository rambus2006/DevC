#include<stdio.h>
main(){
	unsigned int a;
	scanf("%u",&a);
	printf("%u",a);
	}

