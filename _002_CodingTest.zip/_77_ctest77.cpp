#include<stdio.h>
main(){
	int i,n;
	scanf("%c",&n);
	for(i=1;i<=n;i++)
	{
		printf("%d\n",i);
	}
		
	
}	

