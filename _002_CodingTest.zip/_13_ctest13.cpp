#include<stdio.h>

int main(void){
	int x,y;
	scanf("%d : %d",&x,&y);
	printf("%02d : %02d",x,y);
}
